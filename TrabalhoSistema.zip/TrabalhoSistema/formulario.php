
<!DOCTYPE html>
<!-- DUPLA : DANIELLY E FRANCISCO CARLOS
 -->
 <html lang="pt-br">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Criação de diretorios e upload de arquivos</title>
</head>
<body>
	<h2><center> Cômodos da Casa </center></h2>
	<form enctype="multipart/form-data" method="post" action="upload.php">
		<p>Digite o nome dos Cômodos:
         <input type="text" name="diretorio">
		</p>
		<p> <input name="userfile" type="file"/></p>
   	    <div>
		<p> <button type="submit">Enviar</button></p>
		<p> <button type="submit" name="deletar">Deletar arquivo</button></p>
		</div>
</form>
	<a href="galeria.html"><button>VER GALERIA</button></a>

</body>
</html>