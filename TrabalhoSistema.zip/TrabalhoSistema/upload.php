<?php 
 // DUPLA : DANIELLY E FRANCISCO CARLOS

extract($_POST);
$retirar = array(".","..");

if ($diretorio == "") {
	echo "<h1>Nenhum diretorio criado";
	exit;
}

if (isset($deletar)) {
	if (!is_dir("comodos/$diretorio")) {
			echo "<h1>Esse diretorio não existe";
			exit;
}else{
	$file = scandir("comodos/$diretorio");
	$fileF = array_diff($file, $retirar);

	foreach ($fileF as $value) {
		unlink("comodos/$diretorio/$value");
	}
	rmdir("comodos/$diretorio");
	echo "<h1>Diretorio apagado com sucesso";
	exit;
}
}

if (!is_dir("comodos/$diretorio")) {
	mkdir("comodos/$diretorio");
}

$caminho = "comodos/$diretorio";

$nomeTemp = $_FILES["userfile"]['tmp_name'];
$nomeFile = $_FILES["userfile"]['name'];

$parInfo = pathinfo("$nomeFile");

$ext = $parInfo['extension'];

if ($ext == "jpg" || $ext == "png" || $ext == "jpeg") {
	$di = scandir($caminho);
	$remo = array(".","..");
	$dire = array_diff($di, $remo);
	$size = count($dire) + 1;
	$arq = $diretorio.$size.".".$ext;
	if ($size < 4) {
		move_uploaded_file($nomeTemp,$caminho."/".$arq);
		echo "upload realizado";
	}else{
		echo "Não tem mais espaço";
	}
}else{
	echo "Esse tipo de extensão de arquivo não pode ser aceita!";
}


 ?>